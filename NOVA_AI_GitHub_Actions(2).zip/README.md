# NOVA AI — Android v1

Base funcional de un asistente personal para Android.

## Incluye
- Interfaz de chat.
- Motor inicial de comandos.
- Acceso opcional mediante AccessibilityService.
- Servicio de notificaciones opcional.
- Modo privado conceptual.
- Preparación para módulos Roku y Roblox autorizado.
- Apertura de YouTube/TikTok mediante intents.

## Cómo abrir
1. Abre la carpeta en Android Studio.
2. Espera a que Gradle sincronice.
3. Conecta tu Android o usa un emulador.
4. Ejecuta `app`.
5. En NOVA, entra en "Configurar permisos" y activa Accesibilidad solo si quieres que NOVA pueda interactuar con la pantalla.

## Próximos módulos
- Motor LLM real.
- Voz: STT/TTS.
- Lista de apps privadas.
- Alertas VIP.
- Control Roku por LAN.
- Fondo de pantalla.
- Centro de permisos.
- Automatizaciones de varios pasos.
- Módulo de seguridad.
- Integración autorizada con Roblox Studio.

## Privacidad
NOVA no debe intentar saltarse permisos, contraseñas, anti-cheat ni protecciones de aplicaciones. Las acciones sensibles deben pedir confirmación al usuario.
