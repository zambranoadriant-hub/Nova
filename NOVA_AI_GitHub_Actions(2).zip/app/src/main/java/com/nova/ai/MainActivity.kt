package com.nova.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(11,15,25))
        }

        val title = TextView(this).apply {
            text = "NOVA AI"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))

        val privacy = TextView(this).apply {
            text = "🛡️ Privacidad activa • Acciones solo con tus permisos"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(privacy, LinearLayout.LayoutParams(-1, 50))

        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this).apply {
            addView(chat)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        input = EditText(this).apply {
            hint = "Dile algo a NOVA…"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        row.addView(input, LinearLayout.LayoutParams(0, 70, 1f))

        val send = Button(this).apply {
            text = "Enviar"
            setOnClickListener {
                val command = input.text.toString().trim()
                if (command.isNotEmpty()) {
                    addMessage("Tú: $command")
                    val result = NovaCommandEngine.handle(this@MainActivity, command)
                    addMessage("NOVA: $result")
                    input.text.clear()
                }
            }
        }
        row.addView(send, LinearLayout.LayoutParams(130, 70))
        root.addView(row)

        val permissions = Button(this).apply {
            text = "Configurar permisos"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(permissions, LinearLayout.LayoutParams(-1, 60))

        setContentView(root)
        addMessage("NOVA: Hola. Estoy lista. Puedes decirme cosas como “abre YouTube”, “pon esta imagen como fondo” o “modo privado”.")
    }

    private fun addMessage(text: String) {
        val v = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
        }
        chat.addView(v)
    }
}
