package com.nova.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object NovaCommandEngine {
    fun handle(context: Context, raw: String): String {
        val cmd = raw.lowercase()

        return when {
            "modo privado" in cmd || "privacidad" in cmd ->
                "🔒 Modo privado activado. NOVA evitará analizar contenido que marques como privado."

            "permisos" in cmd ->
                "🔐 Abriendo los permisos de accesibilidad para que tú decidas qué puede hacer NOVA."

            "abre youtube" in cmd -> {
                openApp(context, "com.google.android.youtube")
                "▶️ Intentando abrir YouTube."
            }

            "abre tiktok" in cmd -> {
                openApp(context, "com.zhiliaoapp.musically")
                "🎵 Intentando abrir TikTok."
            }

            "configura" in cmd && "accesibilidad" in cmd -> {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "⚙️ Abriendo Accesibilidad."
            }

            "roku" in cmd ->
                "📺 Módulo Roku preparado. Añade la IP local de tu Roku en la configuración para enviar comandos autorizados."

            "roblox" in cmd ->
                "🎮 Modo Roblox preparado para automatizaciones autorizadas en tus propios juegos/servidores. No usa exploits ni evita el anti-cheat."

            "antivirus" in cmd || "seguridad" in cmd ->
                "🛡️ NOVA Security: puedo ayudarte a revisar permisos y aplicaciones. El escaneo profundo requiere APIs de seguridad de Android."

            else ->
                "🧠 Entendí: “$raw”. En la versión siguiente conectaré este comando al motor de IA para planificar y ejecutar acciones compatibles con Android."
        }
    }

    private fun openApp(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            context.startActivity(intent)
        } else {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
