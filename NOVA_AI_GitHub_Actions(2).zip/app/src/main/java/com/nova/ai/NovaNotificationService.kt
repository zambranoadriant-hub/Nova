package com.nova.ai

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NovaNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn?.notification ?: return
        val extras = notification.extras
        val title = extras.getString("android.title") ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        // En una siguiente versión:
        // - lista VIP configurable
        // - alerta flotante
        // - filtros de privacidad
        // - exclusión por aplicación
        println("NOVA notification: $title / $text")
    }
}
