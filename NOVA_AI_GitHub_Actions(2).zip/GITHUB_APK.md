# Crear NOVA.apk automáticamente con GitHub Actions

## 1. Crea un repositorio
En GitHub crea un repositorio nuevo, por ejemplo `NOVA-AI`.

## 2. Sube TODO el contenido de esta carpeta
La carpeta `.github/workflows/build-apk.yml` debe quedar exactamente en:

`.github/workflows/build-apk.yml`

Y `app`, `settings.gradle.kts`, `build.gradle.kts`, etc. deben estar en la raíz.

## 3. Ejecuta la compilación
En GitHub:
- entra al repositorio
- abre **Actions**
- selecciona **Build NOVA APK**
- pulsa **Run workflow**

También se ejecutará automáticamente cuando hagas push a `main`.

## 4. Descarga el APK
Cuando termine:
- abre la ejecución completada
- busca **Artifacts**
- descarga `NOVA-debug-apk`
- dentro estará el APK de NOVA.

## Nota
Es un APK de depuración. Para publicar en Google Play o distribuir una versión final, conviene crear una clave de firma y configurar un build release firmado.
